const conteudo = document.getElementById("conteudo");
const menuToggle = document.querySelector(".menu-toggle");
const navbar = document.getElementById("menu-principal");

const projetosPadrao = [
  { id: 1, nome: "Cesta Solidária", descricao: "Arrecadação de alimentos para famílias em situação de vulnerabilidade.", status: "Em andamento" },
  { id: 2, nome: "Educação Digital", descricao: "Oficinas gratuitas de informática e inclusão digital.", status: "Aberto" },
  { id: 3, nome: "Ação Ambiental", descricao: "Atividades comunitárias de educação e preservação ambiental.", status: "Planejamento" }
];

function carregarProjetos() {
  const dados = localStorage.getItem("projetos");
  return dados ? JSON.parse(dados) : projetosPadrao;
}

function salvarProjetos(projetos) {
  localStorage.setItem("projetos", JSON.stringify(projetos));
}

if (!localStorage.getItem("projetos")) {
  salvarProjetos(projetosPadrao);
}

function renderInicio() {
  return `
    <section class="hero" aria-labelledby="titulo-inicio">
      <h1 id="titulo-inicio">Conecta ONG</h1>
      <p>Plataforma acadêmica para divulgação de projetos sociais e conexão com voluntários.</p>
      <a class="btn btn-primary" href="#" data-rota="projetos">Conhecer projetos</a>
    </section>
  `;
}

function renderProjetos() {
  const projetos = carregarProjetos();
  return `
    <section aria-labelledby="titulo-projetos">
      <h1 id="titulo-projetos">Projetos</h1>
      <div class="grid">
        ${projetos.map(projeto => `
          <article class="card">
            <div>
              <h2>${projeto.nome}</h2>
              <p>${projeto.descricao}</p>
              <span class="badge">${projeto.status}</span>
            </div>
          </article>
        `).join("")}
      </div>
    </section>
  `;
}

function renderVoluntarios() {
  return `
    <section aria-labelledby="titulo-voluntarios">
      <h1 id="titulo-voluntarios">Voluntários</h1>
      <div class="alert" role="status">
        Cadastre-se para demonstrar interesse em participar dos projetos.
      </div>
      <a class="btn btn-primary" href="#" data-rota="cadastro">Quero participar</a>
    </section>
  `;
}

function renderCadastro() {
  return `
    <section aria-labelledby="titulo-cadastro">
      <h1 id="titulo-cadastro">Cadastro de voluntário</h1>
      <form id="form-voluntario" class="form" novalidate>
        <div class="form-group">
          <label for="nome">Nome completo</label>
          <input id="nome" name="nome" type="text" required minlength="3" aria-describedby="nome-feedback">
          <div id="nome-feedback" class="feedback" aria-live="polite"></div>
        </div>

        <div class="form-group">
          <label for="email">E-mail</label>
          <input id="email" name="email" type="email" required aria-describedby="email-feedback">
          <div id="email-feedback" class="feedback" aria-live="polite"></div>
        </div>

        <button class="btn btn-primary" type="submit">Enviar cadastro</button>
        <div id="form-feedback" class="feedback" role="status" aria-live="polite"></div>
      </form>
    </section>
  `;
}

const paginas = {
  inicio: renderInicio,
  projetos: renderProjetos,
  voluntarios: renderVoluntarios,
  cadastro: renderCadastro
};

function navegar(rota) {
  const pagina = paginas[rota] || paginas.inicio;
  conteudo.innerHTML = pagina();
  conteudo.focus();
  configurarEventosDaPagina();
}

function validarCampo(input, feedback, mensagem) {
  if (!input.value.trim()) {
    input.classList.add("error");
    input.classList.remove("success");
    feedback.textContent = mensagem;
    feedback.className = "feedback error";
    return false;
  }

  if (input.type === "email" && !input.validity.valid) {
    input.classList.add("error");
    input.classList.remove("success");
    feedback.textContent = "Digite um e-mail válido.";
    feedback.className = "feedback error";
    return false;
  }

  if (input.minLength > 0 && input.value.trim().length < input.minLength) {
    input.classList.add("error");
    input.classList.remove("success");
    feedback.textContent = "Digite pelo menos 3 caracteres.";
    feedback.className = "feedback error";
    return false;
  }

  input.classList.remove("error");
  input.classList.add("success");
  feedback.textContent = "";
  return true;
}

function configurarFormulario() {
  const form = document.getElementById("form-voluntario");
  if (!form) return;

  const nome = document.getElementById("nome");
  const email = document.getElementById("email");
  const nomeFeedback = document.getElementById("nome-feedback");
  const emailFeedback = document.getElementById("email-feedback");
  const formFeedback = document.getElementById("form-feedback");

  nome.addEventListener("input", () =>
    validarCampo(nome, nomeFeedback, "Informe seu nome completo.")
  );

  email.addEventListener("input", () =>
    validarCampo(email, emailFeedback, "Informe seu e-mail.")
  );

  form.addEventListener("submit", event => {
    event.preventDefault();

    const nomeValido = validarCampo(nome, nomeFeedback, "Informe seu nome completo.");
    const emailValido = validarCampo(email, emailFeedback, "Informe seu e-mail.");

    if (!nomeValido || !emailValido) {
      formFeedback.textContent = "Corrija os campos destacados.";
      formFeedback.className = "feedback error";
      return;
    }

    const cadastros = JSON.parse(localStorage.getItem("voluntarios") || "[]");
    cadastros.push({ nome: nome.value.trim(), email: email.value.trim() });
    localStorage.setItem("voluntarios", JSON.stringify(cadastros));

    form.reset();
    formFeedback.textContent = "Cadastro realizado com sucesso!";
    formFeedback.className = "feedback success";
  });
}

function configurarEventosDaPagina() {
  document.querySelectorAll("[data-rota]").forEach(link => {
    link.addEventListener("click", event => {
      event.preventDefault();
      navegar(link.dataset.rota);
      navbar.classList.remove("active");
      menuToggle.setAttribute("aria-expanded", "false");
    });
  });

  configurarFormulario();
}

menuToggle.addEventListener("click", () => {
  const aberto = navbar.classList.toggle("active");
  menuToggle.setAttribute("aria-expanded", String(aberto));
});

navegar("inicio");
