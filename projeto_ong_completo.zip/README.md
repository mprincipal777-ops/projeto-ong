# Conecta ONG

Projeto acadêmico de desenvolvimento front-end para uma plataforma de projetos sociais e voluntariado.

## Tecnologias

- HTML5 semântico
- CSS3
- JavaScript ES6+
- DOM
- localStorage
- Git e GitHub

## Funcionalidades

- Navegação em formato SPA.
- Layout responsivo com CSS Grid e Flexbox.
- Formulário de cadastro de voluntários.
- Validação de campos em tempo real.
- Mensagens de sucesso e erro.
- Persistência de dados com localStorage.
- Recursos básicos de acessibilidade, incluindo landmarks, labels, foco visível e atributos ARIA.

## Estrutura

```text
projeto_ong/
├── html/
│   └── index.html
├── css/
│   └── style.css
├── js/
│   └── app.js
├── imagens/
└── README.md
```

## Como executar

1. Baixe ou clone o repositório.
2. Abra a pasta do projeto.
3. Abra `html/index.html` no navegador ou utilize um servidor local.
4. Teste a navegação, o formulário e a persistência dos dados.

## Versionamento

O projeto segue uma organização inspirada no GitFlow:

- `main`: versão estável.
- `develop`: desenvolvimento.
- `feature/*`: novas funcionalidades.

Exemplos de commits:

```text
feat: adiciona estrutura inicial da aplicação
feat: implementa layout responsivo
feat: adiciona navegação SPA
feat: implementa validação dos formulários
fix: corrige validação e persistência dos dados
docs: atualiza documentação do projeto
```

Versão final acadêmica: `v1.0.0`.

## Deploy

A aplicação pode ser publicada no GitHub Pages a partir do repositório GitHub.

## Autor

Projeto acadêmico de desenvolvimento front-end.
